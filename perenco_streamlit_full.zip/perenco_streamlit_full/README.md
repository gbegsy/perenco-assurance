# Perenco UK Control of Work Assurance – Streamlit Pilot

This package implements the Perenco/Rebecca direction to use Streamlit as the audit-capture and assurance application, with a Snowflake-ready data model and a route into the corporate action-management system.

## Included
- Three assurance forms: Permit Quality; Leadership Engagement; TBT / Permit / POP.
- Corrected Yes/No wording remains red in the review build.
- Question-level BAR 1 / BAR 2 / BAR 3 tagging (compact badge only).
- KPI 1–5 dashboard logic based on the supplied CoW KPI specification.
- Leadership narrative, BAR performance, Work as Imagined vs Work as Done evidence view, site/auditor view.
- Action management with owner, due date, priority, status and external corporate action ID.
- KPI 5 incident input placeholder pending MOI/Snowflake feed.
- Assurance-plan management for KPI completion calculations.
- JSON backup/restore, CSV exports and a flattened HTML Dashboard Bridge CSV.
- Proposed Snowflake table schema.

## Community Cloud test
Upload `app.py` and `requirements.txt` to the existing GitHub repository and deploy `app.py`. Data is held in the Streamlit session unless Snowflake is configured. Use Data Admin to download a backup before rebooting the app.

## Perenco production architecture
Deploy Streamlit within Perenco's Snowflake environment. Set Streamlit secrets with a `storage` section containing `mode = "snowflake"`, provision the tables in `snowflake_schema.sql`, and have Perenco IT define the final mapping/API or database interface to the corporate action-management system. The application already retains `external_action_id` and action status for that integration.

## Important production decisions for Perenco IT / Assurance
1. Confirm authentication/RBAC roles (auditor, site leadership, assurance manager, read-only leadership).
2. Confirm exact Snowflake database/schema names and retention requirements.
3. Confirm action-management integration method and action-status ownership.
4. Confirm KPI 5 numeric governance for the phrase `significant increase` if a deterministic red threshold is required.
5. Approve the question-level BAR allocation before production use.
6. Replace the red corrected-question review presentation with normal styling once the amended wording is formally approved.
